$(()=>{
    $('#loader').hide();
    $('#b').click(makeCall);
});


function makeCall(){
    let d = {
        number: $('#num').val()
    }
    $('#loader').show();
    fetch("http://localhost:3000/spa",{
        method: "post",
        timeout: 2000
    })
    .then((res)=> res.json())
    .then(sucessfunc)
    .catch(errorfunc)
    .finally(completefunc);
}


function sucessfunc(data){

    for(i of data){
        let h3 = $('<h3>', {
            text: i.name
        });
        let img = $('<img>', {
            src: i.image
        }) 
        let h5 = $('<h5>', {
            text: i.price
        });
        let x = $('<div>', {
            class : "product",
        });
        x.append(h3).append(img).append(h5);
        $('#inventory').prepend(x);
    } 
}
function errorfunc(xhr, status, exception){
    console.log(exception);
    let x = $('<h3>',{
        text: exception
    });
    $('#inventory').prepend(x);
}
function completefunc(){
    $('#loader').hide(); 
}
window.onload = eventFunction;


function eventFunction() { 
    let x = document.getElementById('b').onclick = al;
}


let timer = setInterval(armBomb, 3 * 1000, 15);
function al(){
    //let y = document.getElementById('thep').style = '<img src="https://m.media-amazon.com/images/I/71GEA5leEaL._CR412,0,1060,1060_UX256.jpg"></img>';
    //document.getElementById('thep').className = "clicked";
   clearInterval(timer);
   alert("Phew!");
}

function armBomb(howlongdowehave){
    alert("Bomb armed! Exploding in: " + howlongdowehave + " seconds");
}